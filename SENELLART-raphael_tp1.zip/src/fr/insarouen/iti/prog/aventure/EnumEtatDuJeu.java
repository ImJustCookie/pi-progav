package fr.insarouen.iti.prog.aventure;

enum EnumEtatDuJeu{
    ECHEC,
    ENCOURS,
    SUCCES
}
