package fr.insarouen.iti.prog.aventure;

public enum EnumEtatDuJeu{
    ECHEC,
    ENCOURS,
    SUCCES
}
