package fr.insarouen.iti.prog.aventure.elements;

public interface Executable {

}
