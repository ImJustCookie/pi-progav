package fr.insarouen.iti.prog.aventure.elements;

enum Etat {
    FERME,
    OUVERT,
    CASSE,
    VERROUILLE,
    DEVEROUILLE
}