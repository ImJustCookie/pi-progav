package fr.insarouen.iti.prog.aventure.elements;

public enum Etat {
    FERME,
    OUVERT,
    CASSE,
    VERROUILLE,
    DEVEROUILLE
}